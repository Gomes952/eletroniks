import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Building2, Users, Award, TrendingUp } from "lucide-react"

export default function SobreNos() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 text-balance">Sobre a iStore</h1>

          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Desde 2021, a iStore tem revolucionado o mercado brasileiro de produtos Apple, oferecendo tecnologia de
              ponta com preços até 45% mais acessíveis que a concorrência.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-12">
              <div className="bg-card p-6 rounded-lg border">
                <Building2 className="w-10 h-10 text-accent mb-4" />
                <h3 className="text-xl font-bold mb-2">Nossa História</h3>
                <p className="text-muted-foreground">
                  Fundada em 2021, nascemos com a missão de democratizar o acesso aos produtos Apple no Brasil,
                  oferecendo qualidade premium com preços justos.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg border">
                <Users className="w-10 h-10 text-accent mb-4" />
                <h3 className="text-xl font-bold mb-2">Nossa Equipe</h3>
                <p className="text-muted-foreground">
                  Contamos com especialistas apaixonados por tecnologia, dedicados a proporcionar a melhor experiência
                  de compra para nossos clientes.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg border">
                <Award className="w-10 h-10 text-accent mb-4" />
                <h3 className="text-xl font-bold mb-2">Qualidade Garantida</h3>
                <p className="text-muted-foreground">
                  Todos os nossos produtos são 100% originais, com garantia oficial Apple de 12 meses e nota fiscal em
                  todas as compras.
                </p>
              </div>

              <div className="bg-card p-6 rounded-lg border">
                <TrendingUp className="w-10 h-10 text-accent mb-4" />
                <h3 className="text-xl font-bold mb-2">Crescimento Contínuo</h3>
                <p className="text-muted-foreground">
                  Milhares de clientes satisfeitos em todo o Brasil confiam na iStore para adquirir seus produtos Apple
                  com segurança e economia.
                </p>
              </div>
            </div>

            <h2 className="text-3xl font-bold mt-12 mb-4">Nossa Missão</h2>
            <p className="text-muted-foreground leading-relaxed">
              Tornar a tecnologia Apple acessível a todos os brasileiros, mantendo os mais altos padrões de qualidade,
              autenticidade e atendimento. Acreditamos que todos merecem ter acesso aos melhores produtos do mercado sem
              comprometer o orçamento.
            </p>

            <h2 className="text-3xl font-bold mt-12 mb-4">Nossos Valores</h2>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>
                  <strong>Transparência:</strong> Preços claros e honestos, sem taxas ocultas
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>
                  <strong>Autenticidade:</strong> Apenas produtos originais Apple com garantia oficial
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>
                  <strong>Excelência:</strong> Atendimento de qualidade em todas as etapas da compra
                </span>
              </li>
              <li className="flex items-start">
                <span className="text-accent mr-2">•</span>
                <span>
                  <strong>Inovação:</strong> Sempre buscando as melhores soluções para nossos clientes
                </span>
              </li>
            </ul>

            <div className="bg-accent/10 p-8 rounded-lg mt-12 text-center">
              <p className="text-xl font-semibold mb-2">Junte-se a milhares de clientes satisfeitos</p>
              <p className="text-muted-foreground">
                Faça parte da família iStore e descubra uma nova forma de comprar produtos Apple
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
