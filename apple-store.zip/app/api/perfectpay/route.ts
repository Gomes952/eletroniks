import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const perfectPayToken = process.env.PERFECTPAY_TOKEN
    const perfectPayAppToken = process.env.PERFECTPAY_APP_TOKEN

    if (!perfectPayToken || !perfectPayAppToken) {
      return NextResponse.json(
        {
          success: false,
          error: "Credenciais de pagamento não configuradas",
        },
        { status: 500 },
      )
    }

    const perfectPayData = {
      customer: {
        name: body.fullName,
        email: body.email,
        phone: body.phone.replace(/\D/g, ""),
        document: body.cpf.replace(/\D/g, ""),
      },
      product: {
        name: body.productName,
        price: Math.round(body.productPrice * 100),
      },
      payment: {
        method: body.paymentMethod,
        installments: body.installments || 1,
      },
      shipping: {
        zipcode: body.cep.replace(/\D/g, ""),
        street: body.address,
        number: body.number,
        complement: body.complement || "",
        neighborhood: body.neighborhood,
        city: body.city,
        state: body.state,
      },
    }

    if (body.paymentMethod === "credit" || body.paymentMethod === "debit") {
      perfectPayData.payment = {
        ...perfectPayData.payment,
        card: {
          number: body.cardNumber.replace(/\s/g, ""),
          holder_name: body.cardName,
          expiration: body.expiryDate.replace(/\D/g, ""),
          cvv: body.cvv,
        },
      }
    }

    const response = await fetch("https://api.perfectpay.com.br/api/v2/transactions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${perfectPayToken}`,
        "X-App-Token": perfectPayAppToken,
      },
      body: JSON.stringify(perfectPayData),
    })

    const responseText = await response.text()
    let result

    try {
      result = JSON.parse(responseText)
    } catch (e) {
      return NextResponse.json(
        {
          success: false,
          error: "Erro ao processar resposta do servidor de pagamento",
        },
        { status: 500 },
      )
    }

    if (!response.ok) {
      return NextResponse.json(
        {
          success: false,
          error: result.message || result.error || "Erro ao processar pagamento na PerfectPay",
        },
        { status: response.status },
      )
    }

    return NextResponse.json({
      success: true,
      transaction_id: result.transaction_id || result.id || `TXN-${Date.now()}`,
      status: result.status || "pending",
      payment_method: body.paymentMethod,
      pix_qrcode: result.pix_qrcode || result.qr_code,
      pix_code: result.pix_code || result.qr_code_text,
      boleto_url: result.boleto_url || result.boleto_link,
      boleto_barcode: result.boleto_barcode || result.boleto_code,
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: `Erro interno: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
      },
      { status: 500 },
    )
  }
}
