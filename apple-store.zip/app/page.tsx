import { Header } from "@/components/header"
import { HeroBanner } from "@/components/hero-banner"
import { ProductCategories } from "@/components/product-categories"
import { AboutCEO } from "@/components/about-ceo"
import { Newsletter } from "@/components/newsletter"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroBanner />
        <ProductCategories />
        <AboutCEO />
        <Newsletter />
      </main>
      <Footer />
    </div>
  )
}
