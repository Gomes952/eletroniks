import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function TermosDeUso() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6">Termos de Uso</h1>
          <p className="text-muted-foreground mb-8">Última atualização: Janeiro de 2025</p>

          <div className="prose prose-lg max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-bold mb-4">1. Aceitação dos Termos</h2>
              <p className="text-muted-foreground leading-relaxed">
                Ao acessar e utilizar o site da iStore, você concorda em cumprir e estar vinculado aos seguintes termos
                e condições de uso. Se você não concordar com qualquer parte destes termos, não deverá utilizar nosso
                site ou serviços.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">2. Uso do Site</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                O conteúdo deste site é apenas para sua informação geral e uso. Está sujeito a alterações sem aviso
                prévio. Você concorda em usar o site apenas para fins legais e de maneira que não infrinja os direitos
                de terceiros.
              </p>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Não utilizar o site para fins fraudulentos ou ilegais</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Não tentar obter acesso não autorizado ao site ou sistemas relacionados</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Não transmitir material que contenha vírus ou códigos maliciosos</span>
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">3. Produtos e Preços</h2>
              <p className="text-muted-foreground leading-relaxed">
                Todos os produtos oferecidos pela iStore são 100% originais e acompanhados de nota fiscal. Os preços
                estão sujeitos a alterações sem aviso prévio. Nos reservamos o direito de limitar as quantidades de
                produtos vendidos e de recusar qualquer pedido. Todos os preços estão em Reais (BRL) e incluem impostos
                aplicáveis.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">4. Pedidos e Pagamentos</h2>
              <p className="text-muted-foreground leading-relaxed">
                Ao fazer um pedido, você garante que todas as informações fornecidas são verdadeiras e precisas.
                Reservamo-nos o direito de cancelar qualquer pedido se houver suspeita de fraude ou informações
                incorretas. O pagamento deve ser efetuado através dos métodos disponibilizados no site.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">5. Entrega</h2>
              <p className="text-muted-foreground leading-relaxed">
                Os prazos de entrega são estimativas e podem variar de acordo com a localização e disponibilidade do
                produto. A iStore não se responsabiliza por atrasos causados por transportadoras ou eventos fora de
                nosso controle. Frete grátis disponível para compras acima de R$ 1.000 para todo o Brasil.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">6. Garantia</h2>
              <p className="text-muted-foreground leading-relaxed">
                Todos os produtos possuem garantia oficial Apple de 12 meses contra defeitos de fabricação. A garantia
                não cobre danos causados por mau uso, acidentes ou modificações não autorizadas. Para acionar a
                garantia, entre em contato com nosso suporte.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">7. Trocas e Devoluções</h2>
              <p className="text-muted-foreground leading-relaxed">
                Você tem o direito de desistir da compra em até 7 dias corridos após o recebimento do produto, conforme
                o Código de Defesa do Consumidor. O produto deve estar em perfeitas condições, com embalagem original,
                lacres intactos e todos os acessórios. O reembolso será processado em até 10 dias úteis após a aprovação
                da devolução.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">8. Propriedade Intelectual</h2>
              <p className="text-muted-foreground leading-relaxed">
                Todo o conteúdo do site, incluindo textos, imagens, logos e design, é propriedade da iStore ou de seus
                fornecedores e está protegido por leis de direitos autorais. É proibida a reprodução, distribuição ou
                uso comercial sem autorização prévia por escrito.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">9. Limitação de Responsabilidade</h2>
              <p className="text-muted-foreground leading-relaxed">
                A iStore não será responsável por quaisquer danos diretos, indiretos, incidentais ou consequenciais
                resultantes do uso ou incapacidade de usar nosso site ou produtos, exceto quando exigido por lei.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">10. Alterações nos Termos</h2>
              <p className="text-muted-foreground leading-relaxed">
                Reservamo-nos o direito de modificar estes termos a qualquer momento. As alterações entrarão em vigor
                imediatamente após a publicação no site. É sua responsabilidade revisar periodicamente estes termos.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">11. Lei Aplicável</h2>
              <p className="text-muted-foreground leading-relaxed">
                Estes termos são regidos pelas leis da República Federativa do Brasil. Qualquer disputa relacionada a
                estes termos será submetida à jurisdição exclusiva dos tribunais brasileiros.
              </p>
            </section>

            <div className="bg-card p-6 rounded-lg border mt-12">
              <h3 className="text-xl font-bold mb-2">Dúvidas sobre os Termos de Uso?</h3>
              <p className="text-muted-foreground">
                Se você tiver alguma dúvida sobre nossos Termos de Uso, entre em contato conosco através dos canais de
                atendimento disponíveis no site.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
