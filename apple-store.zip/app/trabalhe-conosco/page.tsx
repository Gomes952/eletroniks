"use client"

import type React from "react"

import { useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { Briefcase, Users, TrendingUp, Heart } from "lucide-react"

export default function TrabalheConosco() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    birthdate: "",
    acceptMessages: false,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Job application:", formData)
    alert("Obrigado pelo interesse! Entraremos em contato em breve.")
    setFormData({
      name: "",
      email: "",
      phone: "",
      birthdate: "",
      acceptMessages: false,
    })
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 text-balance">Trabalhe Conosco</h1>
          <p className="text-xl text-muted-foreground mb-12 leading-relaxed">
            Faça parte da equipe iStore e ajude a revolucionar o mercado de tecnologia no Brasil. Estamos sempre em
            busca de talentos apaixonados por inovação e excelência.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <div className="bg-card p-6 rounded-lg border">
              <Briefcase className="w-10 h-10 text-accent mb-4" />
              <h3 className="text-xl font-bold mb-2">Oportunidades de Crescimento</h3>
              <p className="text-muted-foreground">
                Oferecemos um ambiente dinâmico com oportunidades reais de desenvolvimento profissional e crescimento na
                carreira.
              </p>
            </div>

            <div className="bg-card p-6 rounded-lg border">
              <Users className="w-10 h-10 text-accent mb-4" />
              <h3 className="text-xl font-bold mb-2">Equipe Colaborativa</h3>
              <p className="text-muted-foreground">
                Trabalhe com profissionais talentosos em um ambiente colaborativo, onde suas ideias são valorizadas e
                incentivadas.
              </p>
            </div>

            <div className="bg-card p-6 rounded-lg border">
              <TrendingUp className="w-10 h-10 text-accent mb-4" />
              <h3 className="text-xl font-bold mb-2">Empresa em Crescimento</h3>
              <p className="text-muted-foreground">
                Desde 2021, estamos em constante expansão. Junte-se a nós nessa jornada de sucesso e faça parte da nossa
                história.
              </p>
            </div>

            <div className="bg-card p-6 rounded-lg border">
              <Heart className="w-10 h-10 text-accent mb-4" />
              <h3 className="text-xl font-bold mb-2">Benefícios Atrativos</h3>
              <p className="text-muted-foreground">
                Oferecemos pacote de benefícios competitivo, incluindo vale-refeição, vale-transporte, plano de saúde e
                descontos em produtos.
              </p>
            </div>
          </div>

          <div className="bg-card p-8 rounded-lg border">
            <h2 className="text-2xl font-bold mb-6">Cadastre seu Currículo</h2>
            <p className="text-muted-foreground mb-8">
              Preencha o formulário abaixo e entraremos em contato quando surgir uma oportunidade que combine com seu
              perfil.
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium">
                    Nome Completo *
                  </label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Seu nome completo"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium">
                    E-mail *
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="seu@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-medium">
                    Telefone/WhatsApp *
                  </label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="(00) 00000-0000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="birthdate" className="text-sm font-medium">
                    Data de Nascimento *
                  </label>
                  <Input
                    id="birthdate"
                    type="date"
                    value={formData.birthdate}
                    onChange={(e) => setFormData({ ...formData, birthdate: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <Checkbox
                  id="acceptMessages"
                  checked={formData.acceptMessages}
                  onCheckedChange={(checked) => setFormData({ ...formData, acceptMessages: checked as boolean })}
                />
                <label
                  htmlFor="acceptMessages"
                  className="text-sm text-muted-foreground leading-relaxed cursor-pointer"
                >
                  Autorizo a iStore a enviar mensagens sobre oportunidades de emprego e novidades da empresa através dos
                  contatos fornecidos. Posso cancelar a qualquer momento.
                </label>
              </div>

              <Button type="submit" size="lg" className="w-full md:w-auto px-12">
                Enviar Candidatura
              </Button>

              <p className="text-xs text-muted-foreground">
                * Campos obrigatórios. Seus dados serão tratados conforme nossa Política de Privacidade.
              </p>
            </form>
          </div>

          <div className="mt-12 bg-accent/10 p-8 rounded-lg text-center">
            <h3 className="text-2xl font-bold mb-3">Venha fazer parte do nosso time!</h3>
            <p className="text-muted-foreground text-lg">
              Na iStore, acreditamos que pessoas talentosas e motivadas são o nosso maior ativo. Estamos ansiosos para
              conhecer você!
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
