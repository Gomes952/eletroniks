import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Shield, Lock, Eye, Database } from "lucide-react"

export default function PoliticaDePrivacidade() {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 lg:px-8 py-12 lg:py-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6">Política de Privacidade</h1>
          <p className="text-muted-foreground mb-8">Última atualização: Janeiro de 2025</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
            <div className="bg-card p-4 rounded-lg border flex items-center gap-3">
              <Shield className="w-8 h-8 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-bold">Proteção de Dados</h3>
                <p className="text-sm text-muted-foreground">Seus dados estão seguros</p>
              </div>
            </div>
            <div className="bg-card p-4 rounded-lg border flex items-center gap-3">
              <Lock className="w-8 h-8 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-bold">Criptografia</h3>
                <p className="text-sm text-muted-foreground">Conexão segura SSL</p>
              </div>
            </div>
            <div className="bg-card p-4 rounded-lg border flex items-center gap-3">
              <Eye className="w-8 h-8 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-bold">Transparência</h3>
                <p className="text-sm text-muted-foreground">Uso claro dos dados</p>
              </div>
            </div>
            <div className="bg-card p-4 rounded-lg border flex items-center gap-3">
              <Database className="w-8 h-8 text-accent flex-shrink-0" />
              <div>
                <h3 className="font-bold">LGPD</h3>
                <p className="text-sm text-muted-foreground">Conforme a legislação</p>
              </div>
            </div>
          </div>

          <div className="prose prose-lg max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-bold mb-4">1. Introdução</h2>
              <p className="text-muted-foreground leading-relaxed">
                A iStore está comprometida em proteger sua privacidade e seus dados pessoais. Esta Política de
                Privacidade explica como coletamos, usamos, armazenamos e protegemos suas informações quando você
                utiliza nosso site e serviços, em conformidade com a Lei Geral de Proteção de Dados (LGPD - Lei nº
                13.709/2018).
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">2. Informações que Coletamos</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Coletamos diferentes tipos de informações para fornecer e melhorar nossos serviços:
              </p>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>
                    <strong>Dados de Cadastro:</strong> Nome completo, CPF, e-mail, telefone, data de nascimento
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>
                    <strong>Dados de Entrega:</strong> Endereço completo para envio dos produtos
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>
                    <strong>Dados de Pagamento:</strong> Informações de cartão de crédito (processadas por gateway
                    seguro)
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>
                    <strong>Dados de Navegação:</strong> Endereço IP, tipo de navegador, páginas visitadas, tempo de
                    permanência
                  </span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>
                    <strong>Cookies:</strong> Pequenos arquivos para melhorar sua experiência de navegação
                  </span>
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">3. Como Usamos suas Informações</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">Utilizamos suas informações pessoais para:</p>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Processar e entregar seus pedidos</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Comunicar sobre o status do pedido e atualizações</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Enviar promoções e ofertas (com seu consentimento)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Melhorar nossos produtos e serviços</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Prevenir fraudes e garantir a segurança</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Cumprir obrigações legais e regulatórias</span>
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">4. Compartilhamento de Dados</h2>
              <p className="text-muted-foreground leading-relaxed">
                Não vendemos suas informações pessoais. Compartilhamos dados apenas quando necessário com:
                transportadoras para entrega, processadores de pagamento para transações financeiras, autoridades legais
                quando exigido por lei, e parceiros de serviços que nos auxiliam nas operações (todos sob acordos de
                confidencialidade).
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">5. Segurança dos Dados</h2>
              <p className="text-muted-foreground leading-relaxed">
                Implementamos medidas de segurança técnicas e organizacionais para proteger seus dados, incluindo
                criptografia SSL/TLS, servidores seguros, controle de acesso restrito, monitoramento contínuo e backups
                regulares. No entanto, nenhum método de transmissão pela internet é 100% seguro.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">6. Seus Direitos (LGPD)</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">Conforme a LGPD, você tem direito a:</p>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Confirmar a existência de tratamento de dados</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Acessar seus dados pessoais</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Corrigir dados incompletos, inexatos ou desatualizados</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Solicitar a anonimização, bloqueio ou eliminação de dados</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Revogar o consentimento</span>
                </li>
                <li className="flex items-start">
                  <span className="text-accent mr-2">•</span>
                  <span>Solicitar a portabilidade dos dados</span>
                </li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">7. Cookies</h2>
              <p className="text-muted-foreground leading-relaxed">
                Utilizamos cookies para melhorar sua experiência de navegação, lembrar suas preferências, analisar o
                tráfego do site e personalizar conteúdo. Você pode configurar seu navegador para recusar cookies, mas
                isso pode afetar algumas funcionalidades do site.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">8. Retenção de Dados</h2>
              <p className="text-muted-foreground leading-relaxed">
                Mantemos seus dados pessoais apenas pelo tempo necessário para cumprir as finalidades descritas nesta
                política, atender requisitos legais, resolver disputas e fazer cumprir nossos acordos. Dados de
                transações são mantidos conforme exigido pela legislação fiscal.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">9. Menores de Idade</h2>
              <p className="text-muted-foreground leading-relaxed">
                Nossos serviços não são direcionados a menores de 18 anos. Não coletamos intencionalmente informações de
                menores. Se você é pai ou responsável e acredita que seu filho nos forneceu dados pessoais, entre em
                contato conosco.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">10. Alterações nesta Política</h2>
              <p className="text-muted-foreground leading-relaxed">
                Podemos atualizar esta Política de Privacidade periodicamente. Notificaremos sobre alterações
                significativas por e-mail ou através de aviso em nosso site. Recomendamos revisar esta página
                regularmente.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">11. Contato</h2>
              <p className="text-muted-foreground leading-relaxed">
                Para exercer seus direitos, tirar dúvidas ou fazer solicitações relacionadas à privacidade, entre em
                contato com nosso Encarregado de Proteção de Dados (DPO) através dos canais de atendimento disponíveis
                no site.
              </p>
            </section>

            <div className="bg-accent/10 p-6 rounded-lg mt-12">
              <h3 className="text-xl font-bold mb-2">Seu controle, sua privacidade</h3>
              <p className="text-muted-foreground">
                Na iStore, você tem total controle sobre seus dados pessoais. Estamos comprometidos em proteger sua
                privacidade e garantir transparência em todas as nossas práticas.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
