"use client"

import type React from "react"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Shield, Lock, CreditCard, QrCode, Barcode, CheckCircle, Loader2, AlertCircle } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function PaySecurityPage() {
  const searchParams = useSearchParams()
  const [paymentMethod, setPaymentMethod] = useState("credit")
  const [installments, setInstallments] = useState("1")
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentSuccess, setPaymentSuccess] = useState(false)
  const [paymentResult, setPaymentResult] = useState<any>(null)
  const [paymentError, setPaymentError] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    cpf: "",
    cardNumber: "",
    cardName: "",
    expiryDate: "",
    cvv: "",
    cep: "",
    address: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
  })

  const productName = searchParams.get("product") || "Produto"
  const productPrice = searchParams.get("price") || "0"
  const productColor = searchParams.get("color") || ""
  const productStorage = searchParams.get("storage") || ""
  const productImage = searchParams.get("image") || "/placeholder.svg"

  const calculateInstallmentValue = (installmentCount: number) => {
    const price = Number.parseFloat(productPrice)
    return (price / installmentCount).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)
    setPaymentError(null)

    try {
      // Validação básica
      if (!formData.fullName || !formData.email || !formData.phone || !formData.cpf) {
        throw new Error("Por favor, preencha todos os campos obrigatórios de dados pessoais")
      }

      if (!formData.cep || !formData.address || !formData.number || !formData.city || !formData.state) {
        throw new Error("Por favor, preencha todos os campos obrigatórios de endereço")
      }

      if (
        (paymentMethod === "credit" || paymentMethod === "debit") &&
        (!formData.cardNumber || !formData.cardName || !formData.expiryDate || !formData.cvv)
      ) {
        throw new Error("Por favor, preencha todos os dados do cartão")
      }

      const paymentData = {
        fullName: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        cpf: formData.cpf,
        cardNumber: formData.cardNumber,
        cardName: formData.cardName,
        expiryDate: formData.expiryDate,
        cvv: formData.cvv,
        cep: formData.cep,
        address: formData.address,
        number: formData.number,
        complement: formData.complement,
        neighborhood: formData.neighborhood,
        city: formData.city,
        state: formData.state,
        paymentMethod,
        installments: Number.parseInt(installments),
        productName,
        productPrice: Number.parseFloat(productPrice),
        productColor,
        productStorage,
      }

      const response = await fetch("/api/perfectpay", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(paymentData),
      })

      const result = await response.json()

      if (!response.ok || !result.success) {
        throw new Error(result.error || "Erro ao processar pagamento")
      }

      setPaymentResult(result)
      setPaymentSuccess(true)
    } catch (error) {
      setPaymentError(error instanceof Error ? error.message : "Erro desconhecido ao processar pagamento")
    } finally {
      setIsProcessing(false)
    }
  }

  if (paymentSuccess && paymentResult) {
    return (
      <div className="min-h-screen bg-background py-12 px-4 flex items-center justify-center">
        <Card className="max-w-2xl w-full">
          <CardContent className="pt-6">
            <div className="text-center space-y-6">
              <CheckCircle className="h-20 w-20 text-accent mx-auto" />
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">Pagamento Processado!</h1>
                <p className="text-muted-foreground">Seu pedido foi recebido e está sendo processado</p>
              </div>

              <div className="bg-muted/30 rounded-lg p-6 space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">ID da Transação:</span>
                  <span className="font-mono text-foreground">{paymentResult.transaction_id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Produto:</span>
                  <span className="text-foreground">{productName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Valor:</span>
                  <span className="text-foreground font-bold">
                    {Number.parseFloat(productPrice).toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })}
                  </span>
                </div>
              </div>

              {paymentResult.payment_method === "pix" && (paymentResult.pix_qrcode || paymentResult.pix_code) && (
                <div className="bg-background border border-border rounded-lg p-6">
                  <h3 className="font-semibold mb-4">Escaneie o QR Code para pagar</h3>
                  {paymentResult.pix_qrcode && (
                    <div className="bg-white p-4 rounded-lg inline-block">
                      <img
                        src={paymentResult.pix_qrcode || "/placeholder.svg"}
                        alt="QR Code PIX"
                        className="w-64 h-64"
                      />
                    </div>
                  )}
                  {paymentResult.pix_code && (
                    <div className="mt-4">
                      <p className="text-xs text-muted-foreground mb-2">Ou copie o código PIX:</p>
                      <code className="text-xs bg-muted p-2 rounded block break-all">{paymentResult.pix_code}</code>
                    </div>
                  )}
                  <p className="text-sm text-muted-foreground mt-4">
                    Após o pagamento, seu pedido será processado automaticamente
                  </p>
                </div>
              )}

              {paymentResult.payment_method === "boleto" && paymentResult.boleto_url && (
                <div className="bg-background border border-border rounded-lg p-6">
                  <h3 className="font-semibold mb-4">Boleto Gerado</h3>
                  {paymentResult.boleto_barcode && (
                    <p className="text-sm text-muted-foreground mb-4">
                      Código de barras: <span className="font-mono">{paymentResult.boleto_barcode}</span>
                    </p>
                  )}
                  <Button asChild className="w-full">
                    <a href={paymentResult.boleto_url} target="_blank" rel="noopener noreferrer">
                      Baixar Boleto
                    </a>
                  </Button>
                </div>
              )}

              <Button onClick={() => (window.location.href = "/")} className="w-full">
                Voltar para a Loja
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Shield className="h-8 w-8 text-accent" />
            <h1 className="text-3xl font-bold text-foreground">PaySecurity</h1>
          </div>
          <p className="text-muted-foreground flex items-center justify-center gap-2">
            <Lock className="h-4 w-4" />
            Pagamento 100% seguro e criptografado
          </p>
        </div>

        {paymentError && (
          <div className="max-w-4xl mx-auto mb-6">
            <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-semibold text-red-500 mb-1">Erro ao processar pagamento</h3>
                <p className="text-sm text-red-500/80">{paymentError}</p>
              </div>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-lg">Resumo do Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-square w-full overflow-hidden rounded-lg bg-muted/30 mb-4">
                  <img
                    src={productImage || "/placeholder.svg"}
                    alt={productName}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="border-b border-border pb-4">
                  <h3 className="font-semibold text-foreground mb-2">{productName}</h3>
                  {productColor && (
                    <p className="text-sm text-muted-foreground">
                      Cor: <span className="text-foreground">{productColor}</span>
                    </p>
                  )}
                  {productStorage && (
                    <p className="text-sm text-muted-foreground">
                      Armazenamento: <span className="text-foreground">{productStorage}</span>
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="text-foreground">
                      {Number.parseFloat(productPrice).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Frete</span>
                    <span className="text-accent font-semibold">GRÁTIS</span>
                  </div>
                  <div className="border-t border-border pt-2 flex justify-between">
                    <span className="font-bold text-foreground">Total</span>
                    <span className="font-bold text-foreground text-xl">
                      {Number.parseFloat(productPrice).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                    </span>
                  </div>
                </div>

                <div className="pt-4 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-3">Formas de pagamento aceitas:</p>
                  <div className="flex gap-2 flex-wrap">
                    <img src="/visa-logo.jpg" alt="Visa" className="h-6 object-contain" />
                    <img src="/mastercard-logo.jpg" alt="Mastercard" className="h-6 object-contain" />
                    <img src="/elo-logo.jpg" alt="Elo" className="h-6 object-contain" />
                    <img src="/amex-logo.jpg" alt="Amex" className="h-6 object-contain" />
                    <img src="/pix-logo.jpg" alt="Pix" className="h-6 object-contain" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dados Pessoais</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nome Completo *</Label>
                      <Input
                        id="fullName"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        placeholder="João da Silva"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cpf">CPF *</Label>
                      <Input
                        id="cpf"
                        name="cpf"
                        value={formData.cpf}
                        onChange={handleInputChange}
                        placeholder="000.000.000-00"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail *</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="seu@email.com"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone *</Label>
                      <Input
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        placeholder="(00) 00000-0000"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Forma de Pagamento</CardTitle>
                </CardHeader>
                <CardContent>
                  <Tabs value={paymentMethod} onValueChange={setPaymentMethod} className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="credit" className="flex items-center gap-2" disabled={isProcessing}>
                        <CreditCard className="h-4 w-4" />
                        Crédito
                      </TabsTrigger>
                      <TabsTrigger value="debit" className="flex items-center gap-2" disabled={isProcessing}>
                        <CreditCard className="h-4 w-4" />
                        Débito
                      </TabsTrigger>
                      <TabsTrigger value="pix" className="flex items-center gap-2" disabled={isProcessing}>
                        <QrCode className="h-4 w-4" />
                        PIX
                      </TabsTrigger>
                      <TabsTrigger value="boleto" className="flex items-center gap-2" disabled={isProcessing}>
                        <Barcode className="h-4 w-4" />
                        Boleto
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="credit" className="space-y-4 mt-6">
                      <div className="space-y-2">
                        <Label htmlFor="installments-credit">Parcelas *</Label>
                        <Select value={installments} onValueChange={setInstallments} disabled={isProcessing}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione as parcelas" />
                          </SelectTrigger>
                          <SelectContent>
                            {[...Array(12)].map((_, i) => {
                              const installmentNumber = i + 1
                              return (
                                <SelectItem key={installmentNumber} value={installmentNumber.toString()}>
                                  {installmentNumber}x de {calculateInstallmentValue(installmentNumber)}{" "}
                                  {installmentNumber === 1 ? "à vista" : "sem juros"}
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber">Número do Cartão *</Label>
                        <Input
                          id="cardNumber"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          placeholder="0000 0000 0000 0000"
                          maxLength={19}
                          required
                          disabled={isProcessing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cardName">Nome no Cartão *</Label>
                        <Input
                          id="cardName"
                          name="cardName"
                          value={formData.cardName}
                          onChange={handleInputChange}
                          placeholder="NOME COMO ESTÁ NO CARTÃO"
                          required
                          disabled={isProcessing}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiryDate">Validade *</Label>
                          <Input
                            id="expiryDate"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            placeholder="MM/AA"
                            maxLength={5}
                            required
                            disabled={isProcessing}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cvv">CVV *</Label>
                          <Input
                            id="cvv"
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            placeholder="000"
                            maxLength={4}
                            required
                            disabled={isProcessing}
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="debit" className="space-y-4 mt-6">
                      <div className="bg-accent/10 border border-accent/20 rounded-lg p-4 mb-4">
                        <p className="text-sm text-foreground">
                          <strong>Pagamento à vista no débito</strong>
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          O valor será debitado imediatamente da sua conta
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cardNumber-debit">Número do Cartão *</Label>
                        <Input
                          id="cardNumber-debit"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          placeholder="0000 0000 0000 0000"
                          maxLength={19}
                          required
                          disabled={isProcessing}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cardName-debit">Nome no Cartão *</Label>
                        <Input
                          id="cardName-debit"
                          name="cardName"
                          value={formData.cardName}
                          onChange={handleInputChange}
                          placeholder="NOME COMO ESTÁ NO CARTÃO"
                          required
                          disabled={isProcessing}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="expiryDate-debit">Validade *</Label>
                          <Input
                            id="expiryDate-debit"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            placeholder="MM/AA"
                            maxLength={5}
                            required
                            disabled={isProcessing}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cvv-debit">CVV *</Label>
                          <Input
                            id="cvv-debit"
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            placeholder="000"
                            maxLength={4}
                            required
                            disabled={isProcessing}
                          />
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="pix" className="space-y-4 mt-6">
                      <div className="bg-accent/10 border border-accent/20 rounded-lg p-6 text-center">
                        <QrCode className="h-32 w-32 mx-auto mb-4 text-foreground" />
                        <p className="text-sm text-foreground font-semibold mb-2">
                          Após confirmar o pedido, você receberá o QR Code para pagamento
                        </p>
                        <p className="text-xs text-muted-foreground">
                          O pagamento via PIX é instantâneo e seu pedido será processado imediatamente após a
                          confirmação
                        </p>
                        <div className="mt-4 p-3 bg-background rounded-lg">
                          <p className="text-lg font-bold text-foreground">
                            {Number.parseFloat(productPrice).toLocaleString("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            })}
                          </p>
                          <p className="text-xs text-muted-foreground">Pagamento à vista</p>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="boleto" className="space-y-4 mt-6">
                      <div className="space-y-2">
                        <Label htmlFor="installments-boleto">Parcelas *</Label>
                        <Select value={installments} onValueChange={setInstallments} disabled={isProcessing}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione as parcelas" />
                          </SelectTrigger>
                          <SelectContent>
                            {[...Array(6)].map((_, i) => {
                              const installmentNumber = i + 1
                              return (
                                <SelectItem key={installmentNumber} value={installmentNumber.toString()}>
                                  {installmentNumber}x de {calculateInstallmentValue(installmentNumber)}{" "}
                                  {installmentNumber === 1 ? "à vista" : ""}
                                </SelectItem>
                              )
                            })}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="bg-accent/10 border border-accent/20 rounded-lg p-6 text-center">
                        <Barcode className="h-24 w-24 mx-auto mb-4 text-foreground" />
                        <p className="text-sm text-foreground font-semibold mb-2">
                          Após confirmar o pedido, você receberá o boleto para pagamento
                        </p>
                        <p className="text-xs text-muted-foreground mb-4">
                          O boleto pode ser pago em qualquer banco, lotérica ou aplicativo bancário. O prazo de
                          compensação é de até 2 dias úteis.
                        </p>
                        <div className="p-3 bg-background rounded-lg">
                          <p className="text-lg font-bold text-foreground">
                            {installments}x de {calculateInstallmentValue(Number.parseInt(installments))}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Total:{" "}
                            {Number.parseFloat(productPrice).toLocaleString("pt-BR", {
                              style: "currency",
                              currency: "BRL",
                            })}
                          </p>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Endereço de Entrega</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="cep">CEP *</Label>
                    <Input
                      id="cep"
                      name="cep"
                      value={formData.cep}
                      onChange={handleInputChange}
                      placeholder="00000-000"
                      required
                      disabled={isProcessing}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address">Endereço *</Label>
                    <Input
                      id="address"
                      name="address"
                      value={formData.address}
                      onChange={handleInputChange}
                      placeholder="Rua, Avenida, etc."
                      required
                      disabled={isProcessing}
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="number">Número *</Label>
                      <Input
                        id="number"
                        name="number"
                        value={formData.number}
                        onChange={handleInputChange}
                        placeholder="123"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="complement">Complemento</Label>
                      <Input
                        id="complement"
                        name="complement"
                        value={formData.complement}
                        onChange={handleInputChange}
                        placeholder="Apto, Bloco, etc."
                        disabled={isProcessing}
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="neighborhood">Bairro *</Label>
                      <Input
                        id="neighborhood"
                        name="neighborhood"
                        value={formData.neighborhood}
                        onChange={handleInputChange}
                        placeholder="Centro"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="city">Cidade *</Label>
                      <Input
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleInputChange}
                        placeholder="São Paulo"
                        required
                        disabled={isProcessing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state">Estado *</Label>
                      <Input
                        id="state"
                        name="state"
                        value={formData.state}
                        onChange={handleInputChange}
                        placeholder="SP"
                        maxLength={2}
                        required
                        disabled={isProcessing}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button
                type="submit"
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-bold py-6"
                disabled={isProcessing}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Processando Pagamento...
                  </>
                ) : (
                  <>
                    <Lock className="mr-2 h-5 w-5" />
                    Finalizar Pagamento Seguro
                  </>
                )}
              </Button>

              <div className="text-center text-xs text-muted-foreground">
                <p className="flex items-center justify-center gap-1">
                  <Shield className="h-3 w-3" />
                  Seus dados estão protegidos com criptografia SSL de 256 bits
                </p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
