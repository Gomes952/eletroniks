import { Shield, Truck, CreditCard, Award } from "lucide-react"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="flex flex-col items-center text-center">
            <div className="h-12 w-12 rounded-full bg-accent text-accent-foreground flex items-center justify-center mb-4">
              <Shield className="h-6 w-6" />
            </div>
            <h3 className="font-bold mb-2">Garantia Oficial</h3>
            <p className="text-sm text-primary-foreground/70">12 meses de garantia Apple em todos os produtos</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="h-12 w-12 rounded-full bg-accent text-accent-foreground flex items-center justify-center mb-4">
              <Truck className="h-6 w-6" />
            </div>
            <h3 className="font-bold mb-2">Entrega Segura</h3>
            <p className="text-sm text-primary-foreground/70">Frete grátis para todo Brasil acima de R$ 1.000</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="h-12 w-12 rounded-full bg-accent text-accent-foreground flex items-center justify-center mb-4">
              <CreditCard className="h-6 w-6" />
            </div>
            <h3 className="font-bold mb-2">Pagamento Flexível</h3>
            <p className="text-sm text-primary-foreground/70">Parcele em até 12x sem juros no cartão</p>
          </div>

          <div className="flex flex-col items-center text-center">
            <div className="h-12 w-12 rounded-full bg-accent text-accent-foreground flex items-center justify-center mb-4">
              <Award className="h-6 w-6" />
            </div>
            <h3 className="font-bold mb-2">Produtos Originais</h3>
            <p className="text-sm text-primary-foreground/70">100% originais com nota fiscal</p>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Formas de Pagamento</h4>
              <div className="flex flex-wrap gap-3">
                <img src="/visa-logo.jpg" alt="Visa" className="h-8 object-contain bg-white rounded px-2" />
                <img src="/mastercard-logo.jpg" alt="Mastercard" className="h-8 object-contain bg-white rounded px-2" />
                <img src="/elo-logo.jpg" alt="Elo" className="h-8 object-contain bg-white rounded px-2" />
                <img src="/amex-logo.jpg" alt="American Express" className="h-8 object-contain bg-white rounded px-2" />
                <img src="/pix-logo.jpg" alt="Pix" className="h-8 object-contain bg-white rounded px-2" />
                <img src="/boleto-logo.jpg" alt="Boleto" className="h-8 object-contain bg-white rounded px-2" />
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4">Institucional</h4>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li>
                  <Link href="/sobre-nos" className="hover:text-accent transition-colors">
                    Sobre nós
                  </Link>
                </li>
                <li>
                  <Link href="/politica-de-privacidade" className="hover:text-accent transition-colors">
                    Política de privacidade
                  </Link>
                </li>
                <li>
                  <Link href="/termos-de-uso" className="hover:text-accent transition-colors">
                    Termos de uso
                  </Link>
                </li>
                <li>
                  <Link href="/trabalhe-conosco" className="hover:text-accent transition-colors">
                    Trabalhe conosco
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4">Atendimento</h4>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Central de ajuda
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Trocas e devoluções
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Rastreamento
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-accent transition-colors">
                    Contato
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="text-center text-sm text-primary-foreground/60 pt-8 border-t border-primary-foreground/20">
            <p className="font-semibold text-base mb-2">SINCE 2021</p>
            <p>© 2025 iStore Brasil. TODOS OS DIREITOS RESERVADOS.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
