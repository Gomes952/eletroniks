import { ProductGrid } from "@/components/product-grid"
import { iphones, appleWatches, ipads, macbooks } from "@/lib/products"

export function ProductCategories() {
  return (
    <div className="py-16 lg:py-24">
      <section id="iphones" className="mb-24">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4 tracking-tight">iPhones</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Os smartphones mais avançados do mundo. Agora com preços imbatíveis.
            </p>
          </div>
          <ProductGrid products={iphones} />
        </div>
      </section>

      <section id="watches" className="mb-24 bg-muted py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4 tracking-tight">Apple Watch</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Seu companheiro perfeito para saúde e fitness.
            </p>
          </div>
          <ProductGrid products={appleWatches} />
        </div>
      </section>

      <section id="ipads" className="mb-24">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4 tracking-tight">iPads</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Poder e versatilidade em um design elegante.
            </p>
          </div>
          <ProductGrid products={ipads} />
        </div>
      </section>

      <section id="macbooks" className="mb-24 bg-muted py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4 tracking-tight">MacBooks</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Desempenho profissional para criar sem limites.
            </p>
          </div>
          <ProductGrid products={macbooks} />
        </div>
      </section>
    </div>
  )
}
