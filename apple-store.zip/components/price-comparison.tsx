import { Check } from "lucide-react"

const competitors = [
  { name: "Casas Bahia", logo: "CB" },
  { name: "Americanas", logo: "AM" },
  { name: "Magazine Luiza", logo: "ML" },
]

export function PriceComparison() {
  return (
    <section className="py-16 lg:py-24 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-5xl font-bold mb-4 tracking-tight">Preços até 45% mais baixos</h2>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
            Compare nossos preços com as principais lojas do Brasil e economize muito mais.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {competitors.map((competitor) => (
            <div key={competitor.name} className="bg-primary-foreground/10 backdrop-blur rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-primary-foreground/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">{competitor.logo}</span>
              </div>
              <h3 className="text-xl font-bold mb-2">{competitor.name}</h3>
              <p className="text-primary-foreground/70 text-sm mb-4">Preços até 45% mais altos</p>
              <div className="flex items-center justify-center gap-2 text-sm">
                <Check className="h-4 w-4 text-accent" />
                <span>Comparado e verificado</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-sm text-primary-foreground/60">
            * Preços comparados em {new Date().toLocaleDateString("pt-BR")}. Valores podem variar.
          </p>
        </div>
      </div>
    </section>
  )
}
