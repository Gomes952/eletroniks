import { Quote } from "lucide-react"

export function AboutCEO() {
  return (
    <section className="py-16 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative max-w-xs mx-auto lg:mx-0">
              <div className="aspect-[3/4] rounded-2xl overflow-hidden">
                <img
                  src="https://jpimg.com.br/uploads/2021/05/mulher-loira-de-camisa-branca-olhando-para-a-foto.jpg"
                  alt="Mariana Costa - CEO"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-accent text-accent-foreground p-6 rounded-xl shadow-xl max-w-xs">
                <p className="text-sm font-medium">No mercado desde</p>
                <p className="text-4xl font-bold">2021</p>
              </div>
            </div>

            <div>
              <Quote className="h-12 w-12 text-accent mb-6" />
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6 tracking-tight">
                Nossa missão é democratizar o acesso à tecnologia Apple
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Fundei a AppleStore em 2021 com um objetivo claro: tornar os produtos Apple acessíveis para todos os
                brasileiros. Acreditamos que tecnologia de qualidade não deve ser um privilégio, mas um direito.
              </p>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Com parcerias estratégicas e um modelo de negócio enxuto, conseguimos oferecer os melhores produtos com
                preços até 45% mais baixos que a concorrência, sem comprometer a qualidade e a garantia.
              </p>
              <div>
                <p className="text-xl font-bold text-foreground">Mariana Costa</p>
                <p className="text-sm text-muted-foreground">CEO & Fundadora</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
