"use client"

import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import Link from "next/link"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-md supports-[backdrop-filter]:bg-background/90 border-b border-border/50">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <Link href="/" className="flex items-center gap-2">
            <div className="text-2xl lg:text-3xl font-bold text-foreground tracking-tight">
              i<span className="text-accent">Store</span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <Link href="#iphones" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
              iPhones
            </Link>
            <Link href="#watches" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
              Apple Watch
            </Link>
            <Link href="#ipads" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
              iPads
            </Link>
            <Link href="#macbooks" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
              MacBooks
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Button
              className="md:hidden"
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-border">
            <div className="flex flex-col gap-4">
              <Link href="#iphones" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
                iPhones
              </Link>
              <Link href="#watches" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
                Apple Watch
              </Link>
              <Link href="#ipads" className="text-sm font-medium text-foreground hover:text-accent transition-colors">
                iPads
              </Link>
              <Link
                href="#macbooks"
                className="text-sm font-medium text-foreground hover:text-accent transition-colors"
              >
                MacBooks
              </Link>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
