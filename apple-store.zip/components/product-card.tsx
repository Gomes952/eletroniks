"use client"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingBag, ChevronLeft, ChevronRight } from "lucide-react"
import type { Product } from "@/lib/products"
import { useState } from "react"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const [selectedColor, setSelectedColor] = useState(product.colors?.[0] || "")
  const [selectedStorage, setSelectedStorage] = useState(product.storage?.[0] || "")
  const [currentImageIndex, setCurrentImageIndex] = useState(0)

  const discount = Math.round(((product.competitorPrice - product.price) / product.competitorPrice) * 100)

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % product.images.length)
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + product.images.length) % product.images.length)
  }

  const handleBuyNow = () => {
    const params = new URLSearchParams({
      product: product.name,
      price: product.price.toString(),
      color: selectedColor,
      storage: selectedStorage,
      image: product.images[currentImageIndex],
    })

    window.location.href = `/paysecurity?${params.toString()}`
  }

  return (
    <Card className="group overflow-hidden hover:shadow-2xl transition-all duration-300 border-border/50">
      <div className="relative aspect-square overflow-hidden bg-muted/30">
        <img
          src={product.images[currentImageIndex] || "/placeholder.svg"}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <Badge className="absolute top-4 right-4 bg-accent text-accent-foreground font-semibold">{discount}% OFF</Badge>

        {product.images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm hover:bg-background text-foreground rounded-full p-2 transition-all duration-200 opacity-0 group-hover:opacity-100 hover:scale-110"
              aria-label="Imagem anterior"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm hover:bg-background text-foreground rounded-full p-2 transition-all duration-200 opacity-0 group-hover:opacity-100 hover:scale-110"
              aria-label="Próxima imagem"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </>
        )}

        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {product.images.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentImageIndex(index)}
              className={`h-1.5 rounded-full transition-all ${
                index === currentImageIndex ? "bg-accent w-8" : "bg-white/40 w-1.5 hover:bg-white/60"
              }`}
              aria-label={`Ver imagem ${index + 1}`}
            />
          ))}
        </div>
      </div>

      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-foreground mb-2">{product.name}</h3>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{product.description}</p>

        {product.colors && product.colors.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-medium text-muted-foreground mb-2">Cores disponíveis:</p>
            <div className="flex gap-2 flex-wrap">
              {product.colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                    selectedColor === color
                      ? "border-accent bg-accent text-accent-foreground font-medium"
                      : "border-border bg-card text-foreground hover:border-accent/50"
                  }`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>
        )}

        {product.storage && product.storage.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-medium text-muted-foreground mb-2">Armazenamento:</p>
            <div className="flex gap-2 flex-wrap">
              {product.storage.map((storage) => (
                <button
                  key={storage}
                  onClick={() => setSelectedStorage(storage)}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${
                    selectedStorage === storage
                      ? "border-accent bg-accent text-accent-foreground font-medium"
                      : "border-border bg-card text-foreground hover:border-accent/50"
                  }`}
                >
                  {storage}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground line-through">
              {product.competitorPrice.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </span>
            <span className="text-xs font-medium text-accent">-{discount}%</span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold text-foreground">
              {product.price.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
            </span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-6 pt-0">
        <Button
          className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
          onClick={handleBuyNow}
        >
          <ShoppingBag className="mr-2 h-4 w-4" />
          Comprar Agora
        </Button>
      </CardFooter>
    </Card>
  )
}
