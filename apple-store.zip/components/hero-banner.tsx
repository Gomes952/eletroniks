"use client"

import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import { useEffect, useState } from "react"

const bannerImages = [
  {
    title: "iPhone 15 Pro Max",
    subtitle: "Titânio. Tão forte. Tão leve. Tão Pro.",
    image: "/iphone-15-pro-max-titanium-design-premium.jpg",
  },
  {
    title: "MacBook Pro",
    subtitle: "Poder surpreendente. Desempenho extraordinário.",
    image: "/macbook-pro-sleek-design-workspace.jpg",
  },
  {
    title: "Apple Watch Series 9",
    subtitle: "Mais inteligente. Mais brilhante. Mais poderoso.",
    image: "/apple-watch-series-9-on-wrist-lifestyle.jpg",
  },
]

export function HeroBanner() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % bannerImages.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  return (
    <section className="relative h-[600px] lg:h-[700px] overflow-hidden bg-muted">
      {bannerImages.map((banner, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <img src={banner.image || "/placeholder.svg"} alt={banner.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        </div>
      ))}

      <div className="relative h-full container mx-auto px-4 lg:px-8 flex flex-col justify-center items-center text-center">
        <h1 className="text-4xl lg:text-7xl font-bold text-white mb-4 lg:mb-6 tracking-tight text-balance">
          {bannerImages[currentSlide].title}
        </h1>
        <p className="text-lg lg:text-2xl text-white/90 mb-8 lg:mb-12 max-w-2xl text-balance">
          {bannerImages[currentSlide].subtitle}
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
            Comprar agora
            <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-white/10 backdrop-blur border-white/20 text-white hover:bg-white/20"
          >
            Saiba mais
          </Button>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {bannerImages.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`h-2 rounded-full transition-all ${index === currentSlide ? "w-8 bg-white" : "w-2 bg-white/50"}`}
          />
        ))}
      </div>
    </section>
  )
}
