"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail } from "lucide-react"

export function Newsletter() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Newsletter signup:", formData)
    alert("Obrigado por se inscrever! Você receberá nossas novidades em breve.")
    setFormData({ name: "", email: "", phone: "" })
  }

  return (
    <section className="bg-card py-16 lg:py-24">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-6">
            <Mail className="w-8 h-8 text-accent" />
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold mb-4 text-balance">Fique por dentro das novidades</h2>
          <p className="text-muted-foreground mb-8 text-lg text-pretty">
            Receba em primeira mão nossas promoções exclusivas, lançamentos e ofertas especiais da iStore
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                type="text"
                placeholder="Nome completo"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bg-background"
              />
              <Input
                type="email"
                placeholder="Seu melhor e-mail"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="bg-background"
              />
              <Input
                type="tel"
                placeholder="Telefone (WhatsApp)"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
                className="bg-background"
              />
            </div>
            <Button type="submit" size="lg" className="w-full md:w-auto px-12">
              Quero receber novidades
            </Button>
          </form>

          <p className="text-xs text-muted-foreground mt-4">
            Ao se inscrever, você concorda em receber comunicações da iStore. Você pode cancelar a qualquer momento.
          </p>
        </div>
      </div>
    </section>
  )
}
