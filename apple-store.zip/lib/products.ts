export interface Product {
  id: string
  name: string
  description: string
  price: number
  competitorPrice: number
  images: string[]
  colors?: string[]
  storage?: string[]
  category: "iphone" | "watch" | "ipad" | "macbook"
}

export const iphones: Product[] = [
  {
    id: "iphone-17",
    name: "iPhone 17",
    description:
      'Chip A18 Pro. Câmera de 50MP com IA avançada. Tela Super Retina XDR de 6,3" com ProMotion 120Hz. Design revolucionário.',
    price: 6499,
    competitorPrice: 13999,
    images: [
      "https://images7.kabum.com.br/produtos/fotos/925347/iphone-17-pro-apple-256gb-48mp-tela-6-3-super-retina-xdr-laranja-cosmico_1757690391_gg.jpg",
      "https://images7.kabum.com.br/produtos/fotos/925347/iphone-17-pro-apple-256gb-48mp-tela-6-3-super-retina-xdr-laranja-cosmico_1757690391_gg.jpg",
      "https://images7.kabum.com.br/produtos/fotos/925347/iphone-17-pro-apple-256gb-48mp-tela-6-3-super-retina-xdr-laranja-cosmico_1757690391_gg.jpg",
    ],
    colors: ["Laranja"],
    storage: ["256GB", "512GB", "1TB"],
    category: "iphone",
  },
  {
    id: "iphone-air",
    name: "iPhone Air",
    description:
      'O iPhone mais fino já criado. Chip A18. Câmera de 48MP. Tela Super Retina XDR de 6,1". Apenas 5,9mm de espessura.',
    price: 5999,
    competitorPrice: 12999,
    images: [
      "https://images.tcdn.com.br/img/img_prod/625110/iphone_17_air_256gb_apple_original_light_gold_7657_1_7f88ea0abdbc9c71435a5e728f8ee7ff.jpg",
      "https://images.tcdn.com.br/img/img_prod/625110/iphone_17_air_256gb_apple_original_light_gold_7657_1_7f88ea0abdbc9c71435a5e728f8ee7ff.jpg",
      "https://images.tcdn.com.br/img/img_prod/625110/iphone_17_air_256gb_apple_original_light_gold_7657_1_7f88ea0abdbc9c71435a5e728f8ee7ff.jpg",
    ],
    colors: ["Cinza Espacial"],
    storage: ["256GB", "512GB", "1TB"],
    category: "iphone",
  },
  {
    id: "iphone-16-pro-max",
    name: "iPhone 16 Pro Max",
    description:
      'Chip A18 Pro. Câmera de 48MP com zoom óptico de 6x. Tela Super Retina XDR de 6,9" com ProMotion. Botão de Captura.',
    price: 5899,
    competitorPrice: 13499,
    images: [
      "https://m.media-amazon.com/images/I/71WbxLdbGOL.jpg",
      "https://cdn.awsli.com.br/2510/2510599/produto/308219690/iphone-16-pro-max-256gb-titanio-natural-3392dc06-736r62sp60.jpg",
      "https://carrefourbr.vtexassets.com/arquivos/ids/182538609/image-0.jpg?v=638724823154970000",
    ],
    colors: ["Titânio Deserto", "Titânio Natural", "Titânio Preto"],
    storage: ["256GB", "512GB", "1TB"],
    category: "iphone",
  },
  {
    id: "iphone-16-pro",
    name: "iPhone 16 Pro",
    description:
      'Chip A18 Pro. Câmera de 48MP com zoom óptico de 5x. Tela Super Retina XDR de 6,3" com ProMotion. Botão de Captura.',
    price: 4999,
    competitorPrice: 11999,
    images: [
      "https://m.media-amazon.com/images/I/61ctYsUobKL.jpg",
      "https://modesio.com.br/wp-content/uploads/2025/07/ADASDASADASD.webp",
      "https://cdn.storech.com/uploads/products/000/000/000/000/020/767/300_1726423082-16-pro-natural-2.png",
    ],
    colors: ["Titânio Branco", "Titânio Preto", "Titânio Natural"],
    storage: ["128GB", "256GB", "512GB"],
    category: "iphone",
  },
  {
    id: "iphone-16",
    name: "iPhone 16",
    description: 'Chip A18. Câmera de 48MP com Fusion. Tela Super Retina XDR de 6,1". Botão de Ação. Dynamic Island.',
    price: 4699,
    competitorPrice: 9999,
    images: [
      "https://m.media-amazon.com/images/I/61ctYsUobKL.jpg",
      "https://m.media-amazon.com/images/I/71ZYO1ZBusL._UF1000,1000_QL80_.jpg",
      "https://m.media-amazon.com/images/I/71ZYO1ZBusL._UF1000,1000_QL80_.jpg",
    ],
    colors: ["Branco", "Azul"],
    storage: ["128GB", "256GB", "512GB"],
    category: "iphone",
  },
  {
    id: "iphone-15-pro-max",
    name: "iPhone 15 Pro Max",
    description: 'Titânio. Chip A17 Pro. Câmera de 48MP com zoom óptico de 5x. Tela Super Retina XDR de 6,7".',
    price: 5399,
    competitorPrice: 12549,
    images: [
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v6954342444443958611/products/226687.00-apple-iphone-15-pro-max-de-256gb-titanio-azul-mu7a3be-a.jpg&height=475&width=475",
      "https://m.media-amazon.com/images/I/81YSmKnlijL._UF1000,1000_QL80_.jpg",
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v2923989447140379291/products/226694.00-apple-iphone-15-pro-max-de-512gb-titanio-preto-mu7c3be-a.jpg&height=475&width=475",
    ],
    colors: ["Titânio Azul", "Titânio Natural", "Titânio Preto"],
    storage: ["256GB", "512GB", "1TB"],
    category: "iphone",
  },
  {
    id: "iphone-15-plus",
    name: "iPhone 15 Plus",
    description: 'Tela Super Retina XDR de 6,7". Chip A16 Bionic. Câmera principal de 48MP. Dynamic Island.',
    price: 4799,
    competitorPrice: 9999,
    images: [
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v5698556007205961206/products/226654.00.638514747112045210-apple-iphone-15-plus-512gb-rosa-mu1j3be-a.jpg&height=475&width=475",
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v3391192929426820466/products/226642.00-apple-iphone-15-plus-azul-mu16be-a.jpg&height=475&width=475",
      "https://p.turbosquid.com/ts-thumb/Up/D1QVi7/Qc/appleiphone15plusblackvray3dmodel001/jpg/1697504563/600x600/fit_q87/48dd47a6ae9cdf8b25098e5cd097954df57b30f9/appleiphone15plusblackvray3dmodel001.jpg",
    ],
    colors: ["Rosa", "Azul", "Preto"],
    storage: ["128GB", "256GB", "512GB"],
    category: "iphone",
  },
  {
    id: "iphone-14-pro-max",
    name: "iPhone 14 Pro Max",
    description: 'Dynamic Island. Chip A16 Bionic. Câmera de 48MP. Tela Super Retina XDR de 6,7" com Always-On.',
    price: 3999,
    competitorPrice: 9999,
    images: [
      "https://horizonplay.fbitsstatic.net/img/p/apple-iphone-14-pro-max-256gb-5g-vitrine-tela-super-retina-xdr-oled-6-7-cor-roxo-profundo-150352/336944.jpg?w=670&h=670&v=no-value",
      "https://horizonplay.fbitsstatic.net/img/p/apple-iphone-14-pro-max-256gb-5g-vitrine-tela-super-retina-xdr-oled-6-7-cor-preto-espacial-150353/336945.jpg?w=670&h=670&v=no-value",
      "https://horizonplay.fbitsstatic.net/img/p/apple-iphone-14-pro-max-256gb-5g-vitrine-tela-super-retina-xdr-oled-6-7-cor-dourado-150355/336947.jpg?w=670&h=670&v=202509221149",
    ],
    colors: ["Roxo Profundo", "Preto Espacial", "Dourado"],
    storage: ["256GB", "512GB", "1TB"],
    category: "iphone",
  },
  {
    id: "iphone-14-pro",
    name: "iPhone 14 Pro",
    description: 'Dynamic Island. Chip A16 Bionic. Câmera de 48MP. Tela Super Retina XDR de 6,1" com Always-On.',
    price: 3499,
    competitorPrice: 8999,
    images: [
      "https://fotos.mtdesconto.com.br/ofertas/apple-iphone-14-pro-128gb-dourado-61-48mp_6410da22b3e68.jpg",
      "https://www.buscaparaguai.com.br/original/uploads/JPG/2024/04/12/SASUPA_1712945138.jpg",
      "https://fotos.mtdesconto.com.br/ofertas/apple-iphone-14-pro-128gb-dourado-61-48mp_6410da22b3e68.jpg",
    ],
    colors: ["Dourado", "Prata", "Preto Espacial"],
    storage: ["128GB", "256GB", "512GB"],
    category: "iphone",
  },
  {
    id: "iphone-14-plus",
    name: "iPhone 14 Plus",
    description: 'Chip A15 Bionic. Câmera dupla de 12MP. Tela Super Retina XDR de 6,7". Bateria de longa duração.',
    price: 3299,
    competitorPrice: 7499,
    images: [
      "https://www.iplace.com.br/ccstore/v1/images/?source=/file/v5968126931940399245/products/226616.00.638479211227193924-apple-iphone-14-plus-256gb-roxo-mq563br-a.jpg&height=350&width=350&quality=1.0",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPhUuJFk4gzKj6OmEPfy44_kezK1rx1DItCA&s",
      "https://m.magazineluiza.com.br/a-static/420x420/apple-iphone-14-plus-128gb-estelar-67-12mp/magazineluiza/237891600/07020084904761e8a8850435ac519e2c.jpg",
    ],
    colors: ["Roxo", "Azul Meia-Noite", "Estelar"],
    storage: ["128GB", "256GB", "512GB"],
    category: "iphone",
  },
  {
    id: "iphone-13-pro-max",
    name: "iPhone 13 Pro Max",
    description: 'Chip A15 Bionic. Sistema de câmera Pro. Tela Super Retina XDR de 6,7" com ProMotion 120Hz.',
    price: 2499,
    competitorPrice: 7271,
    images: [
      "https://m.media-amazon.com/images/I/314zgLaT9YL.jpg",
      "https://a-static.mlcdn.com.br/420x420/usado-iphone-13-pro-max-grafite-256gb-muito-bom-trocafy-apple/trocafy/1565/bf147607ac097b2b23566b8dc1e76009.jpeg",
      "https://a-static.mlcdn.com.br/420x420/usado-iphone-13-pro-max-dourado-128gb-excelente-trocafy-apple/trocafy/1348/e6d2604916b3f3bcd5a937ad137a8795.jpeg",
    ],
    colors: ["Azul Sierra", "Grafite", "Dourado"],
    storage: ["256GB", "512GB", "1TB"],
    category: "iphone",
  },
  {
    id: "iphone-13-pro",
    name: "iPhone 13 Pro",
    description: 'Chip A15 Bionic. Sistema de câmera Pro tripla. Tela Super Retina XDR de 6,1" com ProMotion 120Hz.',
    price: 2199,
    competitorPrice: 6499,
    images: [
      "https://leapfone.com.br/_next/image?url=%2Fimages%2Fvariants%2Fapple-iphone-13-pro-dourado.webp&w=1080&q=75",
      "https://img.olx.com.br/images/55/557442839410611.jpg",
      "https://horizonplay.fbitsstatic.net/img/p/apple-iphone-13-pro-128gb-5g-vitrine-tela-super-retina-xdr-oled-6-1-cor-silver-prata-150433/337025.jpg?w=670&h=670&v=no-value",
    ],
    colors: ["Dourado", "Grafite", "Prata"],
    storage: ["128GB", "256GB", "512GB"],
    category: "iphone",
  },
]

export const appleWatches: Product[] = [
  {
    id: "apple-watch-series-9",
    name: "Apple Watch Series 9",
    description: "Chip S9. Tela mais brilhante. Gesto de toque duplo. Detecção de Acidente e Queda. GPS + Cellular.",
    price: 1249,
    competitorPrice: 4999,
    images: [
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v1180172810268021934/products/226804.00-apple-watch-series-9-gps-pulseira-estelar-41mm-mr8t3bz-a.jpg&height=475&width=475",
      "https://http2.mlstatic.com/D_NQ_NP_904860-MLU77370253033_072024-O.webp",
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v9093594294955450411/products/226808.00-apple-watch-series-9-gps-meia-noite-pulseira-esportiva-mr8w3bz-a.jpg&height=475&width=475",
    ],
    colors: ["Estelar", "Rosa", "Meia-Noite"],
    category: "watch",
  },
  {
    id: "apple-watch-ultra-2",
    name: "Apple Watch Ultra 2",
    description: "Caixa de titânio de 49mm. Tela mais brilhante. GPS de precisão dupla. Resistência extrema.",
    price: 3499,
    competitorPrice: 9089,
    images: [
      "https://http2.mlstatic.com/D_NQ_NP_663591-MLA79787646721_102024-O.webp",
      "https://http2.mlstatic.com/D_NQ_NP_663591-MLA79787646721_102024-O.webp",
      "https://http2.mlstatic.com/D_NQ_NP_663591-MLA79787646721_102024-O.webp",
    ],
    colors: ["Titânio Natural"],
    category: "watch",
  },
  {
    id: "apple-watch-se",
    name: "Apple Watch SE",
    description: "Recursos essenciais. Detecção de Queda e Acidente. Monitoramento de sono. À prova d'água.",
    price: 399,
    competitorPrice: 3454,
    images: [
      "https://www.iplace.com.br/ccstore/v1/images/?source=/file/v3048368557252182172/products/100051820.00-apple-watch-se-gps-caixa-prateada-aluminio-40mm-pulseira-loop-esportiva-nuvem-azul-mxee3be-a.jpg&height=424&width=424&quality=0.9",
      "https://www.iplacecorp.com.br/ccstore/v1/images/?source=/file/v7948853430370163181/products/222355.00-apple-watch-se-gps-caixa-estelar-aluminio-40-pulseira-esportiva-estelar-mnjp3bz-a.jpg&height=475&width=475",
      "https://m.media-amazon.com/images/I/51UH9XTBW4L._UF1000,1000_QL80_.jpg",
    ],
    colors: ["Prateado", "Estelar", "Meia-Noite"],
    category: "watch",
  },
]

export const ipads: Product[] = [
  {
    id: "ipad-pro-13",
    name: 'iPad Pro 13"',
    description: "Chip M4. Tela Ultra Retina XDR. Câmera frontal paisagem. Suporte para Apple Pencil Pro.",
    price: 4999,
    competitorPrice: 11816,
    images: [
      "https://www.goimports.com.br/image/catalog/0%20novos%20ipa/ipad-pro-finish-select-202405-11inch-silver_AV1.png",
      "https://www.goimports.com.br/image/catalog/0%20novos%20ipa/ipad-pro-finish-select-202405-11inch-silver_AV1.png",
      "https://www.goimports.com.br/image/catalog/0%20novos%20ipa/ipad-pro-finish-select-202405-11inch-silver_AV1.png",
    ],
    colors: ["Prateado", "Cinza Espacial"],
    storage: ["256GB", "512GB", "1TB"],
    category: "ipad",
  },
  {
    id: "ipad-air",
    name: "iPad Air",
    description: 'Chip M2. Tela Liquid Retina de 11". Câmera frontal paisagem. Suporte para Apple Pencil Pro.',
    price: 2499,
    competitorPrice: 7271,
    images: [
      "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/ipad-air-finish-select-gallery-202405-13inch-purple-wifi_FMT_WHH?wid=1200&hei=630&fmt=jpeg&qlt=95&.v=1713820068209",
      "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/ipad-air-storage-select-202405-13inch-blue-wifi_FMT_WHH?wid=1280&hei=720&fmt=p-jpg&qlt=80&.v=TENLTVRoeFdHUUI5ZE1ZZmxpQUlNMm5pQUoxb0NIVEJFSjRVRzZ4dzV5UWF5K1Z4WkZxY2crb0xCT0VkbitmdjhiZjRKRUJ6ZU96N3VHVCtXdS9WdVVCNWUrcXd0bG5Na3hKOEEyeFZtNE45Q2drLzhtOFgzejV4MENrZ0JFZVBNdmJRYzM3OURVaGR2eHlTRFJJc3JB&traceId=1",
      "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/ipad-air-storage-select-202405-13inch-starlight-wifi_FMT_WHH?wid=1280&hei=720&fmt=p-jpg&qlt=80&.v=TENLTVRoeFdHUUI5ZE1ZZmxpQUlNMm5pQUoxb0NIVEJFSjRVRzZ4dzV5VG9xblRoSytlREYxb2tmSnZTRlIvWmxzVWxuaTA3UGxIdzhKNUtuSEF5VlVtYW1kMXNQLzdDd2NuUVFzTDNlZmEyTE1mSHgwMHh1SlVoUDJNTksyTUZnWG04VnYwV0NCYVhKcVlFN0RlblJR&traceId=1",
    ],
    colors: ["Roxo", "Azul", "Estelar"],
    storage: ["128GB", "256GB", "512GB"],
    category: "ipad",
  },
  {
    id: "ipad-10",
    name: "iPad 10ª geração",
    description: 'Chip A14 Bionic. Tela Liquid Retina de 10,9". Design colorido. Conector USB-C.',
    price: 999,
    competitorPrice: 4543,
    images: [
      "https://horizonplay.fbitsstatic.net/img/p/apple-ipad-10th-geracao-10-9-64gb-wi-fi-cor-rosa-150991/337585-2.jpg?w=420&h=420&v=202510061630",
      "https://cdn.awsli.com.br/600x1000/2557/2557636/produto/229188332/p048910_3-3y553burz6.jpg",
      "https://d1sfzvg6s5tf2e.cloudfront.net/Custom/Content/Products/59/64/5964_ipad-apple-10th-wifi-109-64g-yellow-imp_l1_638230458989404494.webp",
    ],
    colors: ["Rosa", "Azul", "Amarelo"],
    storage: ["64GB", "256GB"],
    category: "ipad",
  },
]

export const macbooks: Product[] = [
  {
    id: "macbook-pro-16-m3-max",
    name: 'MacBook Pro 16" M3 Max',
    description: 'Chip M3 Max. Tela Liquid Retina XDR de 16,2". Até 128GB de memória unificada. Bateria de até 22h.',
    price: 15499,
    competitorPrice: 30907,
    images: [
      "https://p.turbosquid.com/ts-thumb/Sm/suHrEk/Xy/preview0000/png/1700307881/1920x1080/fit_q87/c7aca6e74140c60381d71b83ac1fb5befa045255/preview0000.jpg",
      "https://p.turbosquid.com/ts-thumb/kn/jAJUe7/1U/silver01/jpg/1699476656/600x600/fit_q87/ef3954dd1fd86f7b38f87acfb7e23740ee7fb4f1/silver01.jpg",
      "https://p.turbosquid.com/ts-thumb/kn/jAJUe7/1U/silver01/jpg/1699476656/600x600/fit_q87/ef3954dd1fd86f7b38f87acfb7e23740ee7fb4f1/silver01.jpg",
    ],
    colors: ["Preto Espacial", "Prateado"],
    storage: ["512GB", "1TB", "2TB"],
    category: "macbook",
  },
  {
    id: "macbook-pro-14-m3",
    name: 'MacBook Pro 14" M3',
    description: 'Chip M3. Tela Liquid Retina XDR de 14,2". Até 24GB de memória unificada. Bateria de até 17h.',
    price: 9499,
    competitorPrice: 19998,
    images: [
      "https://cdn.awsli.com.br/2500x2500/284/284108/produto/295469895/mbp-14-silver-2-k4h8mpzibe.jpeg",
      "https://cdn.awsli.com.br/2500x2500/284/284108/produto/295469895/mbp-14-silver-2-k4h8mpzibe.jpeg",
      "https://cdn.awsli.com.br/2500x2500/284/284108/produto/295469895/mbp-14-silver-2-k4h8mpzibe.jpeg",
    ],
    colors: ["Prateado", "Preto Espacial"],
    storage: ["512GB", "1TB"],
    category: "macbook",
  },
  {
    id: "macbook-air-15-m3",
    name: 'MacBook Air 15" M3',
    description: 'Chip M3. Tela Liquid Retina de 15,3". Design fino e leve. Bateria de até 18h.',
    price: 6499,
    competitorPrice: 14543,
    images: [
      "https://http2.mlstatic.com/D_815505-MLB89672081291_082025-O.jpg",
      "https://http2.mlstatic.com/D_815505-MLB89672081291_082025-O.jpg",
      "https://http2.mlstatic.com/D_815505-MLB89672081291_082025-O.jpg",
    ],
    colors: ["Azul Meia-Noite", "Estelar", "Prateado"],
    storage: ["256GB", "512GB"],
    category: "macbook",
  },
  {
    id: "macbook-air-13-m3",
    name: 'MacBook Air 13" M3',
    description: 'Chip M3. Tela Liquid Retina de 13,6". Ultrafino e portátil. Bateria de até 18h.',
    price: 4999,
    competitorPrice: 11816,
    images: [
      "https://d3ed33yzxpekl0.cloudfront.net/images/items/gIZQ7NHNQDhNB1hvp94yFWKxFLEYwXgYyGQtoBbZ.png",
      "https://d3ed33yzxpekl0.cloudfront.net/images/items/gIZQ7NHNQDhNB1hvp94yFWKxFLEYwXgYyGQtoBbZ.png",
      "https://d3ed33yzxpekl0.cloudfront.net/images/items/gIZQ7NHNQDhNB1hvp94yFWKxFLEYwXgYyGQtoBbZ.png",
    ],
    colors: ["Estelar", "Prateado", "Azul Meia-Noite"],
    storage: ["256GB", "512GB"],
    category: "macbook",
  },
]
